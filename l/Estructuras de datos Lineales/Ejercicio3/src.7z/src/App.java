public class App {

    public static void main(String[] args) {
        
        //Llamado al método que contiene los ejercicios
        Ejercicio.Ejercicio3();

    }

}
